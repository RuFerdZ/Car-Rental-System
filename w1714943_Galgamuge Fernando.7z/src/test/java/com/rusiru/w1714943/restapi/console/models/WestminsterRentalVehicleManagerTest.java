package com.rusiru.w1714943.restapi.console.models;

import static org.junit.jupiter.api.Assertions.*;

class WestminsterRentalVehicleManagerTest {

}