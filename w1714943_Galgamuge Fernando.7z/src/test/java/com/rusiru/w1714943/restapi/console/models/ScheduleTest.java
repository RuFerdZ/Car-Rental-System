package com.rusiru.w1714943.restapi.console.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ScheduleTest {

    @Test
    void getCusName() {
    }

    @Test
    void setCusName() {
    }

    @Test
    void getPhoneNo() {
    }

    @Test
    void setPhoneNo() {
    }

    @Test
    void getLicenceNo() {
    }

    @Test
    void setLicenceNo() {
    }

    @Test
    void getPlateNumber() {
    }

    @Test
    void setPlateNumber() {
    }

    @Test
    void getPickUp() {
    }

    @Test
    void setPickUp() {
    }

    @Test
    void getDropOff() {
    }

    @Test
    void setDropOff() {
    }

    @Test
    void equals1() {
    }

    @Test
    void hashCode1() {
    }

    @Test
    void toString1() {
    }
}