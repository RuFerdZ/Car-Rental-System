import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';




@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {


  vehicles : any
  
  cusName:any;
  phoneNo:any;
  NIC:any;
  licenceNo:any;
  plateNo: any;
  pickup:any
  dropoff:any

  message:any
  searchMake : string = "";  

  
  filterData: any;
  data: any;

  constructor( 
    private http : HttpClient,
    ) { }

  ngOnInit() {
    let res = this.http.get("http://localhost:8080/getVehicles");
    res.subscribe((data)=>this.vehicles=data)
  }

  public setData(plate){
    this.plateNo = plate;
    console.log(this.plateNo)
  }
 


  public book(cusName,phone,nic,lnumber,plateNumber,pickUp,dropOff){
    this.cusName = cusName
    this.phoneNo = phone
    this.NIC = nic
    this.licenceNo = lnumber
    this.plateNo = plateNumber
    this.pickup = pickUp
    this.dropoff = dropOff
    
    let obj={
      cusName:this.cusName,
      phoneNo:this.phoneNo,
      NIC:this.NIC,
      licenceNo:this.licenceNo,
      plateNumber: this.plateNo,
      pickUp:this.pickup,
      dropOff:this.dropoff
    }
    console.log(obj)
    return this.http.post("http://localhost:8080/getVehicles",obj).toPromise().then((myObj:any)=>{});

    
  }
  

}
